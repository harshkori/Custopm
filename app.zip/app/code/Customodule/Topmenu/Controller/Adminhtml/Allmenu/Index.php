<?php
namespace Customodule\Topmenu\Controller\Adminhtml\Allmenu;

use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Filesystem;
// use Customodule\Extension\Model\ExtensionFactory;
use Customodule\Topmenu\Model\ResourceModel\View\CollectionFactory;


class Index extends \Magento\Framework\App\Action\Action
{	
	protected $messageManager;
	protected $filesystem;
    protected $collectionFactory;

	protected $dir;

	protected $_pageFactory;
	protected $fileUploader;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		ManagerInterface $messageManager,
		Filesystem $filesystem,
		ResourceConnection $resourceConnection,
        UploaderFactory $fileUploader,
        CollectionFactory $collectionFactory,
        \Magento\Framework\Filesystem\DirectoryList $dir

)
	{	
	    $this->resourceConnection   = 		$resourceConnection;
	    $this->messageManager       = 		$messageManager;
         $this->filesystem           = 		$filesystem;
         $this->fileUploader         = 		$fileUploader;
	    $this->mediaDirectory 	  = 		$filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
         $this->_pageFactory 	       = 		$pageFactory;
    	    $this->collectionFactory 	  = 		$collectionFactory;

		return parent::__construct($context);
	}

	public function execute()
	{
		// exit("hii");
		$file = $this->getRequest()->getFiles('csvfiles');
		print_r($file);
		$page=$this->_pageFactory->create();
		$fileName = ($file && array_key_exists('name', $file)) ? $file['name'] : null;
		$connection = $this->resourceConnection->getConnection();
		$table = $connection->getTableName('temp');


        if ($file && $fileName)
		{
			$target = $this->mediaDirectory->getAbsolutePath('media');
			$uploader = $this->fileUploader->create(['fileId' => $file]);
			$uploader->setAllowedExtensions(['jpg', 'pdf', 'csv', 'png', 'zip']);
			$uploader->setAllowCreateFolders(true);
			$uploader->setAllowRenameFiles(true);
			$result = $uploader->save($target);
               $dataarray=$file['tmp_name'];
               echo $dataarray;
               $handle = fopen($dataarray, "r");
               $x=fgetcsv($handle);
               echo $x;
               while($data = fgetcsv($handle))
               {

               $name= mysqli_real_escape_string($obj->connection(),$data[0]);  
               $password = mysqli_real_escape_string($obj->connection(), $data[1]);
               $email = mysqli_real_escape_string($obj->connection(), $data[2]);
               $mobile = mysqli_real_escape_string($obj->connection(), $data[3]);
               if($name == 'name' || $password == 'password' || $email == 'email' || $mobile == 'mobile')
               {
                    echo "";
               }
               else
               {
                    $querys = "SELECT * FROM importdata WHERE email='$email'";
                         $result=mysqli_query($obj->connection(),$querys);
                         $count = mysqli_num_rows($result);
                         if($count !=0)
                         {
                              $obj->update($name,$email,$password,$mobile);
                         }
                         else
                         {
                              $obj->insert($name,$email,$password,$mobile);

                         }
      
               }
          }
          fclose($handle);


               $model = $this->collectionFactory->create();
               $model->setData('harsh')->save();
               $this->messageManager->addSuccessMessage(__("Data Saved Successfully."));
			echo "yes";
		}	
		else
		{	
			$page->setActiveMenu('Customodule_Topmenu::customenu_configuration');
			$page->getConfig()->getTitle()->prepend(__('Product Import'));
			return $page;

		}

	}

}




	