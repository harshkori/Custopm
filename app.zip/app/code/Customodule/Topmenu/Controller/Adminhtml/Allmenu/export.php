<?php
namespace Customodule\Topmenu\Controller\Adminhtml\Allmenu;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Filesystem ;     
use Magento\Framework\App\Filesystem\DirectoryList;
// use Customodule\Extension\Model\ExtensionFactory;
use Customodule\Topmenu\Model\ViewFactory;
use Customodule\Topmenu\Model\View;

use Magento\Framework\Setup\SchemaSetupInterface;


class Export extends \Magento\Framework\App\Action\Action

{   
    protected $messageManager;
    protected $filesystem;
    protected $collectionFactory;

    protected $dir;

    protected $_pageFactory;
    protected $fileUploader;

    public function __construct
    (
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        ManagerInterface $messageManager,
        Filesystem $filesystem,
        ResourceConnection $resourceConnection,
        UploaderFactory $fileUploader,
        ViewFactory $collectionFactory,
        \Magento\Framework\Filesystem\DirectoryList $dir,
        SchemaSetupInterface $setup,
        View $collection,
        DirectoryList $directoryList,
        \Magento\Framework\File\Csv $csvProcessor,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\App\Response\Http\FileFactory $fileFactory




    )
    {   
        $this->resourceConnection   =       $resourceConnection;
        $this->messageManager       =       $messageManager;
        $this->filesystem           =       $filesystem;
        $this->fileUploader         =       $fileUploader;
        $this->mediaDirectory       =       $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->_pageFactory         =       $pageFactory;
        $this->collectionFactory    =       $collectionFactory;
        $this->setup                =       $setup->startSetup();
        $this->collection           =       $collection;
        $this->directoryList        =       $directoryList;
        $this->csvProcessor         =       $csvProcessor;
        $this->_customerSession     =       $customerSession;
        $this->fileFactory          =       $fileFactory;




        parent::__construct($context, $customerSession);
    }

    public function execute()
    {
        
        $fileName = 'import_product.csv';
        $filePath = $this->directoryList->getPath(\Magento\Framework\App\Filesystem\DirectoryList::VAR_DIR)
            . "/" . $fileName;

        $customer = $this->_customerSession->getCustomer();
        $personalData = $this->getPresonalData($customer);

        $this->csvProcessor
            ->setDelimiter(';')
            ->setEnclosure('"')
            ->saveData($filePath,$personalData);

        return $this->fileFactory->create(
            $fileName,
            [
                'type' => "filename",
                'value' => $fileName,
                'rm' => true,
            ],
            \Magento\Framework\App\Filesystem\DirectoryList::VAR_DIR,
            'application/octet-stream'
        );

    }  
        protected function getPresonalData( \Magento\Customer\Model\Customer $customer )
        {
            $collection=$this->collectionFactory->create();
            $newcollection=$collection->getCollection();
            $data=$newcollection->getData();
      
            $result = [];
            $result[] =
             [
                'name',
                'categories',
                'product_price',
                 'sku',
                 'quantity',
                'description',
                'short_description',
                'tax_class_name',
                'visibility',
                'special_price',
                'product_online',
                'weight',
            ];
            foreach ($data as $key => $value) {

                 $result[]=
                 [
                    $value['name'], 
                    $value['categories'], 
                    $value['product_price'], 
                    $value['sku'], 
                    $value['quantity'], 
                    $value['description'], 
                    $value['short_description'], 
                    $value['tax_class_name'], 
                    $value['visibility'],
                    $value['special_price'],
                    $value['product_online'],
                    $value['weight']

                ];
            }     // code...
            
        $this->messageManager->addError(__('Csv File Downloaded Successfully....'));

        return $result;
        }

}  