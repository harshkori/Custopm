<?php
namespace Customodule\Topmenu\Model;

use \Magento\Framework\Model\AbstractModel;
use \Magento\Framework\DataObject\IdentityInterface;
use Customodule\Topmenu\Api\Data\ViewInterface;

class View extends AbstractModel implements ViewInterface, IdentityInterface
{
    /**
     * Cache tag
     */
    const CACHE_TAG = 'Custmodule_Topmenu';

    /**
     * Post Initialization
     * @return void
     */
    public function _construct()
    {
        $this->_init('Customodule\Topmenu\Model\ResourceModel\View');
    }


    /**
     * Get Title
     *
     * @return string|null
     */
    public function getName()
    {
        return $this->getData(self::P_NM);
    }

    /**
     * Get Content
     *
     * @return string|null
     */
    public function getPrice()
    {
        return $this->getData(self::P_PRICE);
    }

    /**
     * Get Created At
     *
     * @return string|null
     */
    public function getSku()
    {
        return $this->getData(self::SKU);
    }

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId()
    {
        return $this->getData(self::ID);
    }

    /**
     * Return identities
     * @return string[]
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * Set Title
     *
     * @param string $title
     * @return $this
     */
    public function setName($title)
    {
        return $this->setData(self::P_NM, $title);
    }

    /**
     * Set Content
     *
     * @param string $content
     * @return $this
     */
    public function setPrice($content)
    {
        return $this->setData(self::P_PRICE, $content);
    }

    /**
     * Set Created At
     *
     * @param string $createdAt
     * @return $this
     */
    public function setSku($createdAt)
    {
        return $this->setData(self::SKU, $createdAt);
    }

    /**
     * Set ID
     *
     * @param int $id
     * @return $this
     */
    public function setId($id)
    {
        return $this->setData(self::ID, $id);
    }
    
}
