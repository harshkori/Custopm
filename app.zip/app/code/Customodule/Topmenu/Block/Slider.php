<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade to the newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Tutorial
 * @copyright Copyright (C) 2021 Magezon (https://www.magezon.com)
 */

namespace Customodule\Topmenu\Block;

use Magento\Framework\View\Element\Template;

class Slider extends Template
{
    protected $_template = 'Customodule_Topmenu::slider.phtml';

    protected function _toHtml()
    {
        $this->setNewUrls("tel:(02) 8071 4360");
        $this->setNewTitles("(02) 8071 4360");
        $this->setNewUrl("harsh");
        $this->setNewTitle("harsh@gmail.com");
        return parent::_toHtml();
    }

    
}