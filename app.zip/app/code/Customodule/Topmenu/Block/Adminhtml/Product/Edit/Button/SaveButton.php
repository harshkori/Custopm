<?php
namespace Customodule\Topmenu\Block\Adminhtml\Product\Edit\Button;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;
use Customodule\Topmenu\Block\Adminhtml\Product\Edit\Button\GenericButton;

class SaveButton extends GenericButton implements ButtonProviderInterface
{
    public function getButtonData()
    {
        return [
            'label' => __('Save Product'),
            'class' => 'save primary',
            'data_attribute' => [
                'mage-init' => ['button' => ['event' => 'save']],
                'form-role' => 'save',
            ],
            //'on_click' => sprintf("location.href= '%s';", $this->getSaveUrl()),
            'sort_order' => 90
        ];
    }


    
    public function getSaveUrl()
    {
        return $this->getUrl('*/*/save', []) ;
    }
}
